package dev.leocat.recomplauncher;

import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Les requêtes réseau de la page (catalogue, releases GitHub) passent par ici : la page demande
 * /__net?u=URL&ttl=SECONDES et reçoit la réponse, gardée sur disque. Hors ligne, la dernière copie
 * répond, donc la bibliothèque marche toujours (comme dans le launcher PC).
 */
final class Net {
    static final String UA = "RecompLauncher-Android/0.1";
    private static final int MAX_BYTES = 24 * 1024 * 1024;

    private static final class HttpError extends IOException {
        private static final long serialVersionUID = 1L;
        final int code;
        final byte[] body;

        HttpError(int code, byte[] body) {
            super("HTTP " + code);
            this.code = code;
            this.body = body;
        }
    }

    private final File dir;

    Net(File cacheDir) {
        dir = new File(cacheDir, "net");
        dir.mkdirs();
    }

    /** Seuls ces sites sont joignables par la page : le catalogue et les releases GitHub. */
    private static boolean hostOk(String host) {
        if (host == null) return false;
        String h = host.toLowerCase(Locale.ROOT);
        return h.equals("recomplauncher.com") || h.endsWith(".recomplauncher.com")
                || h.equals("recompstore.com") || h.endsWith(".recompstore.com")
                || h.equals("api.github.com") || h.equals("raw.githubusercontent.com")
                || h.equals("github.com");
    }

    WebResourceResponse serve(WebResourceRequest req) {
        Uri q = req.getUrl();
        String target = q.getQueryParameter("u");
        if (target == null) return text(400, "missing u");
        long ttl = parseLong(q.getQueryParameter("ttl"), 3600) * 1000L;
        String auth = header(req.getRequestHeaders(), "X-Auth");

        URL url;
        try {
            url = new URL(target);
        } catch (MalformedURLException e) {
            return text(400, "bad url");
        }
        if (!"https".equals(url.getProtocol()) || !hostOk(url.getHost())) return text(403, "host not allowed");

        File body = new File(dir, key(target) + ".bin");
        long age = body.isFile() ? System.currentTimeMillis() - body.lastModified() : Long.MAX_VALUE;
        if (ttl > 0 && age < ttl) return file(body, "hit");

        try {
            byte[] data = fetch(url, auth);
            write(body, data);
            return resp(200, new ByteArrayInputStream(data), "miss");
        } catch (HttpError e) {
            if (body.isFile()) return file(body, "stale");
            return resp(e.code, new ByteArrayInputStream(e.body), "error");
        } catch (IOException e) {
            if (body.isFile()) return file(body, "stale");
            return text(502, String.valueOf(e.getMessage()));
        }
    }

    void clear() {
        File[] all = dir.listFiles();
        if (all == null) return;
        for (File f : all) f.delete();
    }

    private byte[] fetch(URL url, String auth) throws IOException {
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "application/json, */*");
            if (auth != null && !auth.isEmpty() && "api.github.com".equals(url.getHost())) {
                c.setRequestProperty("Authorization", auth);
            }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            byte[] data = in == null ? new byte[0] : readAll(in);
            if (code < 200 || code >= 300) throw new HttpError(code, data);
            return data;
        } finally {
            c.disconnect();
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                if (out.size() > MAX_BYTES) throw new IOException("Réponse trop grosse");
            }
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    /** Écrit dans un fichier à part puis le met à la place de l'ancien : jamais de copie coupée. */
    private static void write(File f, byte[] data) {
        File tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream o = new FileOutputStream(tmp)) {
            o.write(data);
        } catch (IOException e) {
            tmp.delete();
            return;
        }
        if (!tmp.renameTo(f)) tmp.delete();
    }

    private static String key(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format(Locale.ROOT, "%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return Integer.toHexString(s.hashCode());
        }
    }

    private static long parseLong(String s, long dflt) {
        if (s == null) return dflt;
        try {
            return Long.parseLong(s);
        } catch (NumberFormatException e) {
            return dflt;
        }
    }

    private static String header(Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) {
            if (e.getKey().equalsIgnoreCase(name)) return e.getValue();
        }
        return null;
    }

    private static WebResourceResponse file(File f, String cache) {
        try {
            return resp(200, new FileInputStream(f), cache);
        } catch (IOException e) {
            return text(500, "cache error");
        }
    }

    private static WebResourceResponse text(int code, String msg) {
        return resp(code, new ByteArrayInputStream(msg.getBytes(StandardCharsets.UTF_8)), "error");
    }

    private static WebResourceResponse resp(int code, InputStream in, String cache) {
        // WebResourceResponse refuse les codes 3xx et hors 100..599
        if (code < 100 || code > 599 || (code >= 300 && code < 400)) code = 502;
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        h.put("Cache-Control", "no-store");
        h.put("X-RL-Cache", cache);
        return new WebResourceResponse("application/json", "utf-8", code, code < 400 ? "OK" : "Error", h, in);
    }
}
