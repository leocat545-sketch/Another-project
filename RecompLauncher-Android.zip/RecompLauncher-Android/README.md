# RecompLauncher Android (non officiel)

Version Android de [RecompLauncher](https://github.com/elripalda/RecompLauncher) (Ripalda) : parcourir le
catalogue de recomps, trouver ceux qui publient un **APK Android**, les installer, les mettre à jour, les lancer.

## Obtenir l'APK (build GitHub Actions)

### Depuis une tablette (le navigateur ne sait pas envoyer des dossiers)

1. Sur github.com (mode « Version pour ordinateur » conseillé), ouvre ton repo > **Add file > Upload files** et envoie
   **le zip tel quel** (`RecompLauncher-Android.zip`), sans le décompresser. Commit.
2. **Add file > Create new file** : dans le nom, tape `.github/workflows/android.yml` (chaque `/` crée un dossier),
   colle le contenu de `android-depuis-zip.yml`, puis Commit. Le build démarre tout seul.
3. Onglet **Actions** : attends la coche verte (3 à 5 min), puis récupère `RecompLauncher-Android.apk`
   dans **Releases > latest**.

### Depuis un PC (ou si tu sais envoyer des dossiers)

1. Mets tout le contenu de ce dossier dans un repo GitHub (branche `main`), `.github/workflows/android.yml` compris
   (copie de `build-apk.workflow.yml`).
2. L'onglet **Actions** lance « Build APK » tout seul (ou « Run workflow »).
3. Récupère `RecompLauncher-Android.apk` dans **Releases > latest** (ou dans les artefacts du run).

Dans les deux cas : installe l'APK et autorise « installer des apps inconnues » pour ton navigateur / gestionnaire de fichiers.

La clé de signature est fixe (`app/debug.keystore`, publique) : chaque nouveau build s'installe **par-dessus**
l'ancien sans désinstaller. Pour publier ailleurs, remplace-la par la tienne dans `app/build.gradle`.

## Utilisation

- **Découvrir** : le catalogue de recomplauncher.com. Appuie sur *Scanner* une fois : l'app regarde les releases
  de chaque projet et marque ceux qui ont un APK. Filtre *Avec APK Android*.
- **Fiche d'un jeu** : Installer / Mettre à jour / Jouer / Désinstaller, et toutes les versions Android.
  L'APK adapté au processeur de l'appareil est choisi tout seul. La somme SHA-256 est vérifiée quand GitHub la fournit.
- **Ajouter** : colle un lien GitHub (`github.com/proprio/depot`) : marche pour n'importe quel dépôt dont les
  releases contiennent un `.apk`, y compris tes propres projets.
- **Bibliothèque** : ce qui est installé, avec les mises à jour disponibles.
- **Réglages** : pré-versions, passer par recomplauncher.com ou direct par GitHub, jeton GitHub, langue.

## Limites

- Les recomps Windows / Linux / Mac **ne tournent pas sur Android** : l'app ne gère que les APK publiés dans
  les releases GitHub. Pas de Proton/Wine, Steam, sauvegardes cloud ni profils de la version PC.
- Il faut ta propre copie des jeux : l'app n'en fournit ni n'en télécharge. Chaque APK dit où mettre les fichiers.
- Dépôts GitHub uniquement (pas GitLab / SourceForge).
- Si un APK est signé avec une autre clé que celui déjà installé, Android refuse la mise à jour : désinstalle d'abord.

## Dans le code

| Fichier | Rôle |
|---|---|
| `app/src/main/assets/web/` | L'interface (HTML/CSS/JS pur) |
| `MainActivity.java` | Fenêtre WebView, sert l'interface et relaie le réseau |
| `Net.java` | Requêtes vers le catalogue / GitHub avec copie sur disque (marche hors ligne) |
| `Installer.java`, `InstallReceiver.java` | Téléchargement, SHA-256, installation par `PackageInstaller` |
| `Bridge.java` | Ce que l'interface peut demander à Android (lancer, désinstaller, infos appareil) |

## Licence et crédits

GPL-3.0 (voir `LICENSE`), comme RecompLauncher dont l'identité visuelle, le catalogue et le principe sont repris.
RecompLauncher est de Ripalda : ce projet n'est ni affilié ni approuvé par lui.
