package dev.leocat.recomplauncher;

import org.json.JSONException;
import org.json.JSONObject;

/** Fabrique un JSONObject à partir de paires clé, valeur, sans gérer l'exception partout. */
final class J {
    private J() {}

    static JSONObject o(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) {
                o.put((String) kv[i], kv[i + 1]);
            }
        } catch (JSONException ignored) {
            // clé nulle : on garde ce qui est déjà dedans
        }
        return o;
    }
}
