package dev.leocat.recomplauncher;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.os.Build;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Télécharge un APK (SHA-256 vérifiée quand GitHub la donne) puis le confie à l'installeur d'Android.
 * Le résultat revient par InstallReceiver ; la progression et les erreurs partent vers la page
 * avec MainActivity.emit.
 */
final class Installer {
    private static final class Cancelled extends Exception {
        private static final long serialVersionUID = 1L;
    }

    private final Context ctx;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final Map<String, AtomicBoolean> cancels = new ConcurrentHashMap<>();

    Installer(Context ctx) {
        this.ctx = ctx.getApplicationContext();
    }

    static File apkFile(Context ctx, String id) {
        File d = new File(ctx.getCacheDir(), "apks");
        d.mkdirs();
        return new File(d, id.replaceAll("[^A-Za-z0-9._-]", "_") + ".apk");
    }

    void start(final String id, final String url, final String sha256, final long size) {
        final AtomicBoolean cancel = new AtomicBoolean(false);
        cancels.put(id, cancel);
        pool.execute(() -> {
            try {
                work(id, url, sha256, size, cancel);
            } catch (Cancelled e) {
                apkFile(ctx, id).delete();
                MainActivity.emit("state", J.o("id", id, "state", "cancelled"));
            } catch (Exception e) {
                apkFile(ctx, id).delete();
                String m = e.getMessage();
                MainActivity.emit("state", J.o("id", id, "state", "error", "message", m == null ? e.toString() : m));
            } finally {
                cancels.remove(id);
            }
        });
    }

    void cancel(String id) {
        AtomicBoolean c = cancels.get(id);
        if (c != null) c.set(true);
    }

    void clearApks() {
        File d = new File(ctx.getCacheDir(), "apks");
        File[] all = d.listFiles();
        if (all == null) return;
        for (File f : all) f.delete();
    }

    private void work(String id, String url, String expectSha, long size, AtomicBoolean cancel) throws Exception {
        if (!downloadHostOk(url)) throw new IOException("Lien de téléchargement refusé");
        File apk = apkFile(ctx, id);
        String got = download(id, url, apk, size, cancel);
        if (expectSha != null && expectSha.length() == 64 && !expectSha.equalsIgnoreCase(got)) {
            throw new IOException("La somme SHA-256 ne correspond pas à celle de GitHub : fichier supprimé");
        }
        PackageInfo info = ctx.getPackageManager().getPackageArchiveInfo(apk.getAbsolutePath(), 0);
        if (info == null || info.packageName == null) throw new IOException("Ce fichier n'est pas un APK valide");
        String vn = info.versionName == null ? "" : info.versionName;
        long code = Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
        MainActivity.emit("state", J.o("id", id, "state", "installing", "pkg", info.packageName, "versionName", vn, "versionCode", code));
        commit(id, apk, info.packageName);
    }

    static boolean downloadHostOk(String url) {
        try {
            URL u = new URL(url);
            String h = u.getHost().toLowerCase(Locale.ROOT);
            return "https".equals(u.getProtocol())
                    && (h.equals("github.com") || h.endsWith(".githubusercontent.com")
                    || h.equals("recomplauncher.com") || h.endsWith(".recomplauncher.com")
                    || h.equals("recompstore.com") || h.endsWith(".recompstore.com"));
        } catch (MalformedURLException e) {
            return false;
        }
    }

    /** Les liens de release GitHub passent par une redirection vers un CDN : on la suit à la main, en HTTPS seulement. */
    private HttpURLConnection open(String first) throws IOException {
        String cur = first;
        for (int i = 0; i < 6; i++) {
            URL u = new URL(cur);
            if (!"https".equals(u.getProtocol())) throw new IOException("Redirection non sécurisée refusée");
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", Net.UA);
            c.setRequestProperty("Accept", "application/octet-stream");
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null || loc.isEmpty()) throw new IOException("Redirection vide");
                cur = new URL(u, loc).toString();
                continue;
            }
            if (code != 200) {
                c.disconnect();
                throw new IOException("Le serveur a répondu " + code);
            }
            return c;
        }
        throw new IOException("Trop de redirections");
    }

    private String download(String id, String url, File out, long size, AtomicBoolean cancel) throws Exception {
        HttpURLConnection c = open(url);
        try {
            long total = c.getContentLengthLong();
            if (total <= 0) total = size;
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buf = new byte[64 * 1024];
            long done = 0;
            long last = 0;
            try (InputStream in = c.getInputStream(); OutputStream fo = new FileOutputStream(out)) {
                int n;
                while ((n = in.read(buf)) > 0) {
                    if (cancel.get()) throw new Cancelled();
                    fo.write(buf, 0, n);
                    md.update(buf, 0, n);
                    done += n;
                    long now = System.currentTimeMillis();
                    if (now - last > 250) {
                        last = now;
                        MainActivity.emit("progress", J.o("id", id, "done", done, "total", total));
                    }
                }
            }
            MainActivity.emit("progress", J.o("id", id, "done", done, "total", total));
            return hex(md.digest());
        } finally {
            c.disconnect();
        }
    }

    private static String hex(byte[] d) {
        StringBuilder sb = new StringBuilder();
        for (byte b : d) sb.append(String.format(Locale.ROOT, "%02x", b));
        return sb.toString();
    }

    /** Passe l'APK à PackageInstaller ; Android demande la confirmation à l'utilisateur. */
    private void commit(String id, File apk, String pkg) throws IOException {
        PackageInstaller pi = ctx.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params =
                new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(pkg);
        int sid = pi.createSession(params);
        PackageInstaller.Session session = pi.openSession(sid);
        try {
            try (InputStream in = new FileInputStream(apk);
                 OutputStream out = session.openWrite("base.apk", 0, apk.length())) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                session.fsync(out);
            }
            Intent i = new Intent(ctx, InstallReceiver.class);
            i.setAction(InstallReceiver.ACTION);
            i.putExtra("id", id);
            i.putExtra("pkg", pkg);
            // Android ajoute des infos à l'intent de retour : il doit être modifiable (Android 12+)
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pending = PendingIntent.getBroadcast(ctx, sid, i, flags);
            session.commit(pending.getIntentSender());
        } catch (IOException | RuntimeException e) {
            session.abandon();
            throw e;
        } finally {
            session.close();
        }
    }
}
