package dev.leocat.recomplauncher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;

/** Reçoit ce que l'installeur d'Android répond : à confirmer, réussi, annulé ou en échec. */
public class InstallReceiver extends BroadcastReceiver {
    static final String ACTION = "dev.leocat.recomplauncher.INSTALL_RESULT";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        String id = intent.getStringExtra("id");
        if (id == null) return;
        String pkg = intent.getStringExtra("pkg");
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        String msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);

        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm == null) return;
            MainActivity a = MainActivity.current;
            if (a != null) {
                a.startActivity(confirm);
            } else {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(confirm);
            }
            return;
        }

        Installer.apkFile(ctx, id).delete();
        if (status == PackageInstaller.STATUS_SUCCESS) {
            MainActivity.emit("state", J.o("id", id, "state", "done", "pkg", pkg == null ? "" : pkg));
        } else if (status == PackageInstaller.STATUS_FAILURE_ABORTED) {
            MainActivity.emit("state", J.o("id", id, "state", "cancelled"));
        } else {
            MainActivity.emit("state", J.o("id", id, "state", "error", "message", friendly(status, msg)));
        }
    }

    private static String friendly(int status, String msg) {
        if (msg != null && msg.contains("DOWNGRADE")) {
            return "Android refuse de revenir à une version plus ancienne : désinstalle le jeu d'abord (ses données seront perdues).";
        }
        if (status == PackageInstaller.STATUS_FAILURE_CONFLICT) {
            return "Une version signée avec une autre clé est déjà installée : désinstalle-la d'abord.";
        }
        if (status == PackageInstaller.STATUS_FAILURE_INCOMPATIBLE) {
            return "Cet APK n'est pas compatible avec cet appareil (architecture ou version d'Android).";
        }
        if (status == PackageInstaller.STATUS_FAILURE_STORAGE) return "Pas assez de place pour installer.";
        if (status == PackageInstaller.STATUS_FAILURE_BLOCKED) return "Installation bloquée par le système.";
        if (status == PackageInstaller.STATUS_FAILURE_INVALID) return "APK invalide ou abîmé.";
        return msg == null || msg.isEmpty() ? "L'installation a échoué." : msg;
    }
}
