package dev.leocat.recomplauncher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONArray;

/** Ce que la page peut demander à Android : window.Android.xxx(). Appelé hors du thread principal. */
final class Bridge {
    private final Activity act;
    private final Installer installer;
    private final Net net;

    Bridge(Activity act, Installer installer, Net net) {
        this.act = act;
        this.installer = installer;
        this.net = net;
    }

    /** Infos sur l'appareil : architectures, droit d'installer des APK, version de l'app. */
    @JavascriptInterface
    public String info() {
        PackageManager pm = act.getPackageManager();
        boolean can = Build.VERSION.SDK_INT < 26 || pm.canRequestPackageInstalls();
        JSONArray abis = new JSONArray();
        for (String a : Build.SUPPORTED_ABIS) abis.put(a);
        String ver = "0";
        try {
            String v = pm.getPackageInfo(act.getPackageName(), 0).versionName;
            if (v != null) ver = v;
        } catch (PackageManager.NameNotFoundException ignored) {
            // on garde "0"
        }
        return J.o("sdk", Build.VERSION.SDK_INT, "abis", abis, "canInstall", can, "version", ver,
                "device", Build.MANUFACTURER + " " + Build.MODEL).toString();
    }

    /** Version installée d'un paquet, ou "" s'il n'est pas installé. */
    @JavascriptInterface
    public String pkgInfo(String pkg) {
        if (pkg == null || pkg.isEmpty()) return "";
        try {
            PackageInfo pi = act.getPackageManager().getPackageInfo(pkg, 0);
            long code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            return J.o("versionName", pi.versionName == null ? "" : pi.versionName, "versionCode", code).toString();
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    @JavascriptInterface
    public void download(String id, String url, String sha256, long size) {
        installer.start(id, url, sha256, size);
    }

    @JavascriptInterface
    public void cancel(String id) {
        installer.cancel(id);
    }

    @JavascriptInterface
    public boolean launch(String pkg) {
        final Intent i = act.getPackageManager().getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        act.runOnUiThread(() -> {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                act.startActivity(i);
            } catch (RuntimeException e) {
                toast("Impossible de lancer le jeu");
            }
        });
        return true;
    }

    @JavascriptInterface
    public void uninstall(String pkg) {
        final Uri u = Uri.parse("package:" + pkg);
        act.runOnUiThread(() -> {
            try {
                act.startActivity(new Intent(Intent.ACTION_DELETE, u));
            } catch (RuntimeException e) {
                toast("Impossible d'ouvrir la désinstallation");
            }
        });
    }

    /** Ouvre l'écran Android où l'on autorise cette app à installer d'autres apps. */
    @JavascriptInterface
    public void openInstallSettings() {
        act.runOnUiThread(() -> {
            Intent i;
            if (Build.VERSION.SDK_INT >= 26) {
                i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.getPackageName()));
            } else {
                i = new Intent(Settings.ACTION_SECURITY_SETTINGS);
            }
            try {
                act.startActivity(i);
            } catch (RuntimeException e) {
                toast("Ouvre Réglages > Apps > RecompLauncher > Installer des apps inconnues");
            }
        });
    }

    @JavascriptInterface
    public void openUrl(String url) {
        if (url == null || !url.startsWith("https://")) return;
        final Uri u = Uri.parse(url);
        act.runOnUiThread(() -> {
            try {
                act.startActivity(new Intent(Intent.ACTION_VIEW, u));
            } catch (RuntimeException e) {
                toast("Aucun navigateur trouvé");
            }
        });
    }

    @JavascriptInterface
    public void clearCache() {
        net.clear();
        installer.clearApks();
    }

    private void toast(final String msg) {
        Toast.makeText(act, msg, Toast.LENGTH_LONG).show();
    }
}
