/* RecompLauncher pour Android — interface.
 * JavaScript pur, sans bibliothèque. Côté Android : window.Android (Bridge.java) et /__net (Net.java).
 * Inspiré de RecompLauncher de Ripalda (GPL-3.0) : version Android non officielle.
 */
(() => {
'use strict';

const SITE = 'https://recomplauncher.com';
const THUMBS = 'https://recompstore.com/api/thumb.php';

// ---------- petits outils ----------
const $ = (s, r = document) => r.querySelector(s);
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fold = (x) => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
// Recherche : sans accents ni ponctuation, pour que "pokemon" trouve Pokémon.
const sfold = (x) => fold(x).replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
const uniq = (a) => Array.from(new Set(a));

const store = {
  get(k, d) {
    try { const v = localStorage.getItem('rl.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; }
  },
  set(k, v) {
    try { localStorage.setItem('rl.' + k, JSON.stringify(v)); } catch (e) { /* stockage plein ou coupé */ }
  },
};

// ---------- côté Android ----------
const A = window.Android || null;
const nat = {
  has: !!A,
  info() {
    try { return JSON.parse(A.info()); } catch (e) {
      return { sdk: 0, abis: ['arm64-v8a', 'armeabi-v7a'], canInstall: true, version: 'web', device: '' };
    }
  },
  pkg(p) { try { const s = A.pkgInfo(p); return s ? JSON.parse(s) : null; } catch (e) { return null; } },
  download(id, url, sha, size) { if (A) A.download(id, url, sha || '', size || 0); },
  cancel(id) { if (A) A.cancel(id); },
  launch(p) { try { return !!A.launch(p); } catch (e) { return false; } },
  uninstall(p) { if (A) A.uninstall(p); },
  perm() { if (A) A.openInstallSettings(); },
  open(u) { if (A) A.openUrl(u); else window.open(u, '_blank'); },
  clear() { if (A) A.clearCache(); },
};

// Événements envoyés par Android : progress, state, resume
const handlers = {};
const on = (ev, fn) => { (handlers[ev] = handlers[ev] || []).push(fn); };
window.__native = { emit(ev, data) { (handlers[ev] || []).forEach((fn) => fn(data)); } };

// ---------- textes ----------
const FR = {
  'Discover': 'Découvrir', 'Library': 'Bibliothèque', 'Add': 'Ajouter', 'Settings': 'Réglages',
  'Search recomps…': 'Chercher un recomp…', 'All': 'Tous', 'Android builds': 'Avec APK Android', 'Installed games': 'Installés',
  'Mine': 'Ajoutés par moi', 'Refresh': 'Actualiser', 'Scan': 'Scanner', 'Scan again': 'Rescanner', 'Stop': 'Arrêter',
  'Find Android builds': 'Trouver les APK Android',
  'Most recomps are PC-only. Scan the catalog to find the ones that publish an Android APK.':
    'La plupart des recomps sont faits pour PC. Scanne le catalogue pour trouver ceux qui publient un APK Android.',
  'Scanning {done}/{total}…': 'Scan en cours {done}/{total}…',
  '{n} recomps publish an Android APK': '{n} recomps publient un APK Android',
  'Offline: showing the last saved list': 'Hors ligne : dernière liste enregistrée',
  'Nothing here': 'Rien à afficher', 'Loading the catalog…': 'Chargement du catalogue…',
  "Couldn't load the catalog": 'Impossible de charger le catalogue', 'Retry': 'Réessayer',
  'No Android build found yet. Press Scan to look through the catalog.': "Aucun APK Android trouvé pour l'instant. Appuie sur Scanner pour fouiller le catalogue.",
  'Allow installs': 'Autoriser les installations',
  'Android needs your OK before RecompLauncher can install APKs.': "Android doit d'abord autoriser RecompLauncher à installer des APK.",
  'Open settings': 'Ouvrir les réglages',
  'Back': 'Retour', 'Install': 'Installer', 'Update': 'Mettre à jour', 'Play': 'Jouer', 'Uninstall': 'Désinstaller', 'Cancel': 'Annuler',
  'Preparing…': 'Préparation…', 'Downloading {a} / {b}': 'Téléchargement {a} / {b}',
  'Installing… confirm in the Android window': "Installation… confirme dans la fenêtre d'Android",
  'Looking for an Android build…': "Recherche d'un APK Android…",
  'No Android build in the releases': "Pas d'APK Android dans les releases",
  'Android versions': 'Versions Android', 'Release notes': 'Notes de version',
  'Source on GitHub': 'Code sur GitHub', 'Releases': 'Releases', 'Issues': 'Problèmes',
  'Before you play': 'Avant de jouer',
  'You need your own copy of the game. RecompLauncher never includes or downloads game files: the recomp tells you where to put yours.':
    "Il te faut ta propre copie du jeu. RecompLauncher n'inclut ni ne télécharge jamais de fichiers de jeu : c'est le recomp qui t'indique où mettre les tiens.",
  'Installed version': 'Version installée', 'pre-release': 'pré-version', 'checked by GitHub': 'vérifié par GitHub',
  'By {who}': 'Par {who}', 'Not found': 'Introuvable', 'Installed ✓': 'Installé ✓', 'Latest': 'Dernière',
  'Nothing installed yet': "Rien d'installé pour l'instant",
  'Install a recomp from Discover, or add one from GitHub.': 'Installe un recomp depuis Découvrir, ou ajoutes-en un depuis GitHub.',
  'Check for updates': 'Chercher les mises à jour', 'Update available': 'Mise à jour dispo', 'Up to date': 'À jour',
  'Add a recomp from GitHub': 'Ajouter un recomp depuis GitHub',
  'Paste a GitHub link (or owner/repo). Its releases must contain an Android .apk.':
    'Colle un lien GitHub (ou proprio/dépôt). Ses releases doivent contenir un .apk Android.',
  'Look up': 'Chercher', 'Not a GitHub repo': "Ce n'est pas un dépôt GitHub",
  'No Android .apk in the releases of {repo}': 'Aucun .apk Android dans les releases de {repo}',
  'Only pre-releases have an APK: turn them on in Settings.': "Seules des pré-versions ont un APK : active-les dans les Réglages.",
  'Looking…': 'Recherche…', 'Your recomps': 'Tes recomps ajoutés', 'Remove': 'Retirer',
  'Include pre-releases': 'Inclure les pré-versions', 'Betas and nightly builds': 'Bêtas et builds nightly',
  'Release info through recomplauncher.com': 'Releases via recomplauncher.com',
  "Faster, and avoids GitHub's request limit. Off = straight from GitHub.": 'Plus rapide et évite la limite de GitHub. Désactivé = direct depuis GitHub.',
  'GitHub token (optional)': 'Jeton GitHub (optionnel)',
  'Only used when asking GitHub directly, to raise its request limit.': 'Utilisé seulement en direct avec GitHub, pour relever sa limite de requêtes.',
  'Language': 'Langue', 'Automatic': 'Automatique', 'Clear cache': 'Vider le cache', 'Cache cleared': 'Cache vidé',
  'About': 'À propos', 'Unofficial Android version of RecompLauncher by Ripalda (GPL-3.0).': 'Version Android non officielle de RecompLauncher par Ripalda (GPL-3.0).',
  'Device': 'Appareil', 'Supported CPUs': 'Processeurs compatibles',
  'Installed': 'Installé', 'Install cancelled': 'Installation annulée', 'Install failed': "Échec de l'installation",
  'Game installed': 'Jeu installé', "Can't launch this game": 'Impossible de lancer ce jeu',
  'No answer': 'Pas de réponse', 'Unexpected answer from recomplauncher.com': 'Réponse inattendue de recomplauncher.com',
  'GitHub limits requests: add a token in Settings or try again later': 'GitHub limite les requêtes : ajoute un jeton dans Réglages ou réessaie plus tard',
  'Not found on the server': 'Introuvable sur le serveur', 'No connection': 'Pas de connexion', 'Error {n}': 'Erreur {n}',
  'Unreadable answer': 'Réponse illisible', 'Added {name}': '{name} ajouté',
  'Pick a file below to install a specific version.': 'Choisis une version ci-dessous pour installer celle-là.',
  'Action': 'Action', 'Action games': 'Action',
  'Adventure': 'Aventure', 'Platformers': 'Plateforme', 'Racing': 'Course', 'Fighting': 'Combat', 'Shooters': 'Tir', 'Sports': 'Sport', 'Puzzle': 'Puzzle',
  'Mac': 'Mac', 'recomps': 'recomps', 'Show': 'Afficher',
};
const lang = () => (S.set.lang === 'auto' ? ((navigator.language || 'en').toLowerCase().startsWith('fr') ? 'fr' : 'en') : S.set.lang);
const t = (s, v) => {
  let x = lang() === 'fr' && FR[s] !== undefined ? FR[s] : s;
  if (v) Object.keys(v).forEach((k) => { x = x.split('{' + k + '}').join(v[k]); });
  return x;
};
const GENRES = { action: 'Action', adventure: 'Adventure', platformer: 'Platformers', racing: 'Racing', fighting: 'Fighting', shooter: 'Shooters', sports: 'Sports', rpg: 'RPG', puzzle: 'Puzzle' };
const OS_NAME = { windows: 'Windows', macos: 'Mac', linux: 'Linux', android: 'Android' };

// ---------- état ----------
const S = {
  route: { n: 'discover' }, stack: [],
  native: { abis: ['arm64-v8a', 'armeabi-v7a'], canInstall: true, sdk: 0, version: '', device: '' },
  set: Object.assign({ pre: false, relay: true, token: '', lang: 'auto' }, store.get('set', {})),
  inst: store.get('inst', {}),        // id -> {pkg, repo, name, cover, tag, sig, asset, v, at}
  mine: store.get('mine', []),        // recomps ajoutés par lien GitHub
  apk: store.get('apk', {}),          // repo -> {at, has, tag} (résultat du scan)
  pending: store.get('pending', {}),  // id -> ce qui est en cours d'installation
  apps: [], origins: [], loading: true, catErr: '', catCache: '',
  rels: {}, upd: {}, live: {}, busy: {},
  f: { q: '', genre: '', show: 'all' },
  scan: { running: false, done: 0, total: 0, stop: false },
  page: null, addVal: '', addMsg: '', addBusy: false,
};

// ---------- réseau ----------
function netMsg(status) {
  if (status === 403 || status === 429) return t('GitHub limits requests: add a token in Settings or try again later');
  if (status === 404) return t('Not found on the server');
  if (status === 502 || status === 504) return t('No connection');
  return t('Error {n}', { n: status });
}

// Tout passe par Android (/__net) : copie sur disque, et la dernière copie répond hors ligne.
async function net(url, opts) {
  const o = Object.assign({ ttl: 3600, auth: false }, opts || {});
  const headers = {};
  if (o.auth && S.set.token) headers['X-Auth'] = 'Bearer ' + String(S.set.token).trim();
  const r = await fetch('/__net?u=' + encodeURIComponent(url) + '&ttl=' + o.ttl, { headers, cache: 'no-store' });
  if (!r.ok) {
    const e = new Error(netMsg(r.status));
    e.status = r.status;
    throw e;
  }
  let data;
  try { data = await r.json(); } catch (e) { throw new Error(t('Unreadable answer')); }
  return { data, cache: r.headers.get('X-RL-Cache') || '' };
}

function normApp(a) {
  const githubHost = !a.host || /^github$/i.test(a.host);
  const repo = githubHost && /^[\w.-]+\/[\w.-]+$/.test(a.repo || '') ? a.repo : '';
  return Object.assign({}, a, { name: a.name || a.game || a.id, repo });
}

async function loadCatalog(force) {
  S.loading = true;
  S.catErr = '';
  render();
  try {
    const r = await net(SITE + '/pc-catalog.json', { ttl: force ? 0 : 3600 });
    if (!r.data || !Array.isArray(r.data.apps)) throw new Error(t('Unexpected answer from recomplauncher.com'));
    S.apps = r.data.apps.filter((a) => a && a.id).map(normApp);
    S.origins = Array.isArray(r.data.origins) ? r.data.origins : [];
    S.catCache = r.cache;
  } catch (e) {
    S.catErr = e.message;
  }
  S.loading = false;
  refreshPkgs();
  render();
}

// Les releases d'un dépôt : par recomplauncher.com (qui demande à GitHub une fois pour tout le monde),
// sinon directement à GitHub.
async function releases(repo, force) {
  const hit = S.rels[repo];
  if (hit && !force && Date.now() - hit.at < 6 * 3600e3) return hit.list;
  let list = null;
  let lastErr = null;
  if (S.set.relay) {
    try { list = (await net(SITE + '/api/gh.php?repo=' + repo, { ttl: force ? 0 : 6 * 3600 })).data; } catch (e) { lastErr = e; }
  }
  if (!Array.isArray(list)) {
    try {
      list = (await net('https://api.github.com/repos/' + repo + '/releases?per_page=20', { ttl: force ? 0 : 3600, auth: true })).data;
    } catch (e) { lastErr = e; }
  }
  if (!Array.isArray(list)) throw lastErr || new Error(t('No answer'));
  S.rels[repo] = { at: Date.now(), list };
  return list;
}

// ---------- quel APK choisir ----------
function abiOf(name) {
  const n = String(name).toLowerCase();
  if (/arm64|aarch64|v8a|armv8/.test(n)) return 'arm64-v8a';
  if (/armeabi|armv7|v7a|(^|[^a-z0-9])arm([^a-z0-9]|$)/.test(n)) return 'armeabi-v7a';
  if (/x86[_-]?64|amd64/.test(n)) return 'x86_64';
  if (/(^|[^a-z0-9])x86([^a-z0-9]|$)|i[3-6]86/.test(n)) return 'x86';
  return 'universal';
}

function globMatch(pattern, name) {
  const re = new RegExp('^' + String(pattern).replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + '$', 'i');
  return re.test(name);
}

// Le meilleur APK d'une release pour cet appareil : son processeur d'abord, un APK "universel" juste après.
function pickApk(assets, abis, hint) {
  const list = (assets || []).filter((a) => a && /\.apk$/i.test(a.name || '') && !/unsigned/i.test(a.name) && a.browser_download_url && a.size > 0);
  let best = null;
  let bestRank = 99;
  list.forEach((a) => {
    const abi = abiOf(a.name);
    let r = abi === 'universal' ? 0.5 : abis.indexOf(abi);
    if (r < 0) return;
    if (/debug/i.test(a.name)) r += 0.25;
    if (hint && globMatch(hint, a.name)) r -= 0.1;
    if (r < bestRank) { best = a; bestRank = r; }
  });
  return best;
}

// Ce qui change quand le développeur remet un fichier sous le même tag (nightly, latest…)
const sigOf = (rel, asset) => rel.tag_name + '|' + (asset.digest || (asset.size + ':' + (asset.updated_at || '')));

const hintOf = (app) => (app && app.assets && typeof app.assets.android === 'string' ? app.assets.android : '');

function latestApk(list, app, anyRelease) {
  const hint = hintOf(app);
  for (const rel of list) {
    if (!rel || rel.draft || (rel.prerelease && !S.set.pre && !anyRelease)) continue;
    const asset = pickApk(rel.assets, S.native.abis, hint);
    if (asset) return { rel, asset, sig: sigOf(rel, asset) };
  }
  return null;
}

function apkReleases(list, app, max) {
  const out = [];
  const hint = hintOf(app);
  for (const rel of list) {
    if (out.length >= max) break;
    if (!rel || rel.draft || (rel.prerelease && !S.set.pre)) continue;
    const asset = pickApk(rel.assets, S.native.abis, hint);
    if (asset) out.push({ rel, asset, sig: sigOf(rel, asset) });
  }
  return out;
}

function parseRepo(x) {
  const s = String(x || '').trim().replace(/\.git$/i, '').replace(/\/+$/, '');
  let m = /^(?:https?:\/\/)?(?:www\.)?github\.com\/([\w.-]+)\/([\w.-]+)(?:[/?#].*)?$/i.exec(s);
  if (!m) m = /^([\w.-]+)\/([\w.-]+)$/.exec(s);
  if (!m || /^github\.com$/i.test(m[1])) return '';
  return m[1] + '/' + m[2];
}

// ---------- formats ----------
function fmtSize(b) {
  const u = lang() === 'fr' ? ['o', 'Ko', 'Mo', 'Go'] : ['B', 'KB', 'MB', 'GB'];
  let n = Number(b) || 0;
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i >= 2 ? n.toFixed(1) : Math.round(n)) + ' ' + u[i];
}
function fmtDate(d) {
  if (!d) return '';
  try { return new Date(d).toLocaleDateString(lang(), { year: 'numeric', month: 'short', day: 'numeric' }); } catch (e) { return ''; }
}

// ---------- images ----------
const THUMB_RE = /^https:\/\/(?:www\.)?recomp(?:store|launcher)\.com\/media\/([A-Za-z0-9][A-Za-z0-9._-]{0,150}\.(?:jpe?g|png|webp))$/i;
const webUrl = (u) => (!u ? '' : /^(https?:|data:)/.test(u) ? u : SITE + (u[0] === '/' ? '' : '/') + u);
function thumb(u, w) {
  const x = webUrl(u);
  const m = THUMB_RE.exec(x);
  const W = [160, 256, 320, 400, 640, 960].find((v) => v >= (w || 400)) || 960;
  return m ? THUMBS + '?f=' + encodeURIComponent(m[1]) + '&w=' + W : x;
}
const img = (u, w, alt) => `<img loading="lazy" decoding="async" src="${esc(thumb(u, w))}" data-fb="${esc(webUrl(u))}" alt="${esc(alt || '')}">`;
// Une miniature qui ne charge pas : on retente avec l'image d'origine.
document.addEventListener('error', (e) => {
  const i = e.target;
  if (i && i.tagName === 'IMG' && i.dataset.fb && i.src !== i.dataset.fb && !i.dataset.tried) { i.dataset.tried = '1'; i.src = i.dataset.fb; }
}, true);

// ---------- icônes ----------
const ICON = {
  compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  grid: '<rect x="4" y="4" width="7" height="7" rx="1.5"/><rect x="13" y="4" width="7" height="7" rx="1.5"/><rect x="4" y="13" width="7" height="7" rx="1.5"/><rect x="13" y="13" width="7" height="7" rx="1.5"/>',
  plus: '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
  sliders: '<path d="M4 7h9M17 7h3M4 17h3M11 17h9"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="17" r="2"/>',
  back: '<path d="M15 5l-7 7 7 7"/>',
  download: '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
  play: '<path d="M8 5v14l11-7z" fill="currentColor"/>',
  trash: '<path d="M5 7h14M10 7V4h4v3M7 7l1 13h8l1-13"/>',
  refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.7M20 4v5h-5"/>',
  search: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l4 4"/>',
  ext: '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
};
const svg = (k) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICON[k]}</svg>`;

// ---------- données dérivées ----------
function allApps() {
  const seen = new Set(S.apps.map((a) => (a.repo || '').toLowerCase()).filter(Boolean));
  return S.apps.concat(S.mine.filter((m) => !seen.has(m.repo.toLowerCase())));
}
function byId(id) {
  const a = allApps().find((x) => x.id === id);
  if (a) return a;
  const r = S.inst[id];
  return r ? { id, name: r.name, repo: r.repo, cover: r.cover, mine: true } : null;
}
const originName = (id) => (S.origins.find((o) => o.id === id) || {}).name || id || '';
const hasApk = (a) => (a.systems || []).indexOf('android') >= 0 || !!(a.repo && S.apk[a.repo] && S.apk[a.repo].has) || !!S.inst[a.id];
const isInstalled = (id) => !!(S.inst[id] && S.live[id]);
const tabOf = () => (S.route.n === 'game' ? (S.route.from || 'discover') : S.route.n);

function filtered() {
  const q = sfold(S.f.q);
  let list = allApps().filter((a) => !a.soon);
  if (S.f.show === 'apk') list = list.filter(hasApk);
  if (S.f.show === 'installed') list = list.filter((a) => isInstalled(a.id));
  if (S.f.show === 'mine') list = list.filter((a) => a.mine);
  if (S.f.genre) list = list.filter((a) => a.genre === S.f.genre);
  if (q) list = list.filter((a) => sfold([a.name, a.game, a.author, originName(a.origin), a.genre].join(' ')).indexOf(q) >= 0);
  const stars = (a) => Number(a.stars) || 0;
  return list.sort((a, b) => (hasApk(b) - hasApk(a)) || (stars(b) - stars(a)) || String(a.name).localeCompare(String(b.name)));
}

// ---------- installé ou pas ----------
function refreshPkgs() {
  S.native = nat.info();
  const live = {};
  Object.keys(S.inst).forEach((id) => {
    const info = nat.pkg(S.inst[id].pkg);
    if (info) live[id] = info;
    else if (nat.has && !S.busy[id]) delete S.inst[id]; // désinstallé depuis Android
  });
  S.live = live;
  // Une installation dont la page n'a pas reçu la réponse (appli passée en arrière-plan, par exemple)
  Object.keys(S.pending).forEach((id) => {
    const p = S.pending[id];
    const info = p.pkg ? nat.pkg(p.pkg) : null;
    const same = info && p.versionName && info.versionName === p.versionName
      && (p.versionCode == null || Number(info.versionCode) === Number(p.versionCode));
    if (same) {
      delete S.busy[id];
      commitInstall(id);
      S.live[id] = info;
    }
  });
  store.set('inst', S.inst);
}

function commitInstall(id) {
  const p = S.pending[id];
  if (!p) return;
  S.inst[id] = { pkg: p.pkg, repo: p.repo, name: p.name, cover: p.cover, tag: p.tag, sig: p.sig, asset: p.asset, v: p.versionName || '', at: Date.now() };
  delete S.pending[id];
  delete S.upd[id];
  store.set('inst', S.inst);
  store.set('pending', S.pending);
}

async function checkUpdates(force) {
  const next = {};
  await Promise.all(Object.keys(S.inst).map(async (id) => {
    const rec = S.inst[id];
    if (!rec || !rec.repo) return;
    try {
      const best = latestApk(await releases(rec.repo, force), byId(id));
      if (best && best.sig !== rec.sig) next[id] = best;
    } catch (e) { /* hors ligne : on garde ce qu'on sait */ }
  }));
  S.upd = next;
  renderNav();
  if (S.route.n === 'lib' || S.route.n === 'game') render();
}

// ---------- installer ----------
async function doInstall(id, sig) {
  const app = byId(id);
  if (!app || !app.repo || S.busy[id]) return;
  S.native = nat.info();
  if (!S.native.canInstall) { render(); toast(t('Allow installs')); return; }
  S.busy[id] = { state: 'prep' };
  render();
  try {
    const list = await releases(app.repo, true);
    let pick = null;
    if (sig) pick = apkReleases(list, app, 30).find((x) => x.sig === sig) || null;
    if (!pick) pick = latestApk(list, app);
    if (!pick) throw new Error(t('No Android build in the releases'));
    const rel = pick.rel;
    const asset = pick.asset;
    const sha = String(asset.digest || '').replace(/^sha256:/i, '');
    S.pending[id] = { repo: app.repo, name: app.name, cover: app.cover || '', tag: rel.tag_name, sig: pick.sig, asset: asset.name };
    store.set('pending', S.pending);
    S.busy[id] = { state: 'download', done: 0, total: asset.size };
    render();
    nat.download(id, asset.browser_download_url, /^[0-9a-f]{64}$/i.test(sha) ? sha : '', asset.size);
  } catch (e) {
    delete S.busy[id];
    delete S.pending[id];
    render();
    toast(e.message);
  }
}

on('progress', (d) => {
  const b = S.busy[d.id];
  if (!b) return;
  b.state = 'download';
  b.done = d.done;
  b.total = d.total;
  paintProgress(d.id);
});

on('state', (d) => {
  const id = d.id;
  const p = S.pending[id];
  if (d.state === 'installing') {
    S.busy[id] = { state: 'installing' };
    if (p) { p.pkg = d.pkg; p.versionName = d.versionName; p.versionCode = d.versionCode; store.set('pending', S.pending); }
  } else if (d.state === 'done') {
    if (p && d.pkg) p.pkg = d.pkg;
    delete S.busy[id];
    commitInstall(id);
    refreshPkgs();
    toast(t('Game installed'));
    checkUpdates(false);
  } else if (d.state === 'cancelled') {
    delete S.busy[id];
    delete S.pending[id];
    store.set('pending', S.pending);
    toast(t('Install cancelled'));
  } else if (d.state === 'error') {
    delete S.busy[id];
    delete S.pending[id];
    store.set('pending', S.pending);
    toast(d.message || t('Install failed'));
  }
  render();
});

on('resume', () => {
  refreshPkgs();
  renderNav();
  render();
});

function paintProgress(id) {
  const b = S.busy[id];
  document.querySelectorAll('[data-prog]').forEach((el) => {
    if (el.dataset.prog !== id || !b) return;
    const pct = b.total ? Math.min(100, (b.done / b.total) * 100) : 0;
    const bar = el.querySelector('i');
    const txt = el.querySelector('.pt');
    if (bar) bar.style.width = pct + '%';
    if (txt) txt.textContent = t('Downloading {a} / {b}', { a: fmtSize(b.done), b: fmtSize(b.total) });
  });
}

// ---------- scan : quels recomps ont un APK ----------
async function scan() {
  if (S.scan.running) return;
  const day = 24 * 3600e3;
  const todo = uniq(allApps().filter((a) => a.repo && !a.soon).map((a) => a.repo)).filter((r) => !S.apk[r] || Date.now() - S.apk[r].at > day);
  S.scan = { running: true, done: 0, total: todo.length, stop: false };
  render();
  const queue = todo.slice();
  const worker = async () => {
    while (queue.length && !S.scan.stop) {
      const repo = queue.shift();
      try {
        const best = latestApk(await releases(repo, false), null);
        S.apk[repo] = { at: Date.now(), has: !!best, tag: best ? best.rel.tag_name : '' };
      } catch (e) { /* un dépôt qui ne répond pas : on passe au suivant */ }
      S.scan.done++;
      paintScan();
    }
  };
  await Promise.all([worker(), worker(), worker(), worker()]);
  S.scan.running = false;
  store.set('apk', S.apk);
  render();
}

function paintScan() {
  const bar = $('#scanbar');
  const txt = $('#scantxt');
  if (bar) bar.style.width = (S.scan.total ? (S.scan.done / S.scan.total) * 100 : 0) + '%';
  if (txt) txt.textContent = t('Scanning {done}/{total}…', { done: S.scan.done, total: S.scan.total });
}

// ---------- vues ----------
function permBanner() {
  if (S.native.canInstall) return '';
  return `<div class="banner warn"><div><b>${t('Allow installs')}</b><p>${t('Android needs your OK before RecompLauncher can install APKs.')}</p></div>
    <button class="btn pri" data-act="perm">${t('Open settings')}</button></div>`;
}

function scanBanner() {
  const cand = allApps().filter((a) => a.repo && !a.soon);
  if (!cand.length) return '';
  if (S.scan.running) {
    const pct = S.scan.total ? (S.scan.done / S.scan.total) * 100 : 0;
    return `<div class="banner"><div class="grow"><b id="scantxt">${t('Scanning {done}/{total}…', { done: S.scan.done, total: S.scan.total })}</b>
      <div class="bar"><i id="scanbar" style="width:${pct}%"></i></div></div><button class="btn" data-act="scanstop">${t('Stop')}</button></div>`;
  }
  const known = cand.filter((a) => S.apk[a.repo]).length;
  if (known < cand.length * 0.5) {
    return `<div class="banner"><div><b>${t('Find Android builds')}</b><p>${t('Most recomps are PC-only. Scan the catalog to find the ones that publish an Android APK.')}</p></div>
      <button class="btn pri" data-act="scan">${t('Scan')}</button></div>`;
  }
  const n = cand.filter(hasApk).length;
  return `<div class="note">${t('{n} recomps publish an Android APK', { n })} · <button class="lnk" data-act="scan">${t('Scan again')}</button></div>`;
}

function tile(a) {
  const badges = [];
  if (isInstalled(a.id)) badges.push(S.upd[a.id] ? `<b class="bd upd">${t('Update')}</b>` : `<b class="bd ok">${t('Installed')}</b>`);
  else if (hasApk(a)) badges.push('<b class="bd apk">APK</b>');
  const pic = a.cover ? img(a.cover, 400, a.name) : '';
  return `<button class="tile" data-act="open" data-id="${esc(a.id)}"><span class="poster"><span class="ph">${esc(a.name)}</span>${pic}${badges.join('')}</span><span class="tn">${esc(a.name)}</span></button>`;
}

function gridHtml() {
  if (S.loading && !S.apps.length && !S.mine.length) return `<div class="empty"><span class="spin"></span> ${t('Loading the catalog…')}</div>`;
  if (S.catErr && !S.apps.length) {
    return `<div class="empty"><p>${t("Couldn't load the catalog")}</p><p class="muted">${esc(S.catErr)}</p><button class="btn" data-act="reload">${t('Retry')}</button></div>`;
  }
  const list = filtered();
  if (!list.length) {
    const hint = S.f.show === 'apk' && !S.f.q ? `<p class="muted">${t('No Android build found yet. Press Scan to look through the catalog.')}</p>` : '';
    return `<div class="empty"><p>${t('Nothing here')}</p>${hint}</div>`;
  }
  return list.map(tile).join('');
}

function viewDiscover() {
  const shows = [['all', t('All')], ['apk', t('Android builds')], ['installed', t('Installed games')]];
  if (S.mine.length) shows.push(['mine', t('Mine')]);
  const present = uniq(allApps().map((a) => a.genre).filter((g) => GENRES[g]));
  const genres = Object.keys(GENRES).filter((g) => present.indexOf(g) >= 0);
  return `
    <header class="top"><h1>${t('Discover')}</h1>
      <label class="search">${svg('search')}<input id="q" type="search" value="${esc(S.f.q)}" placeholder="${esc(t('Search recomps…'))}" autocomplete="off" autocapitalize="off" spellcheck="false"></label>
      <button class="ibtn" data-act="reload" aria-label="${esc(t('Refresh'))}">${svg('refresh')}</button>
    </header>
    ${S.catCache === 'stale' ? `<div class="note">${t('Offline: showing the last saved list')}</div>` : ''}
    ${permBanner()}${scanBanner()}
    <div class="chips">${shows.map((s) => `<button class="chip${S.f.show === s[0] ? ' on' : ''}" data-act="show" data-v="${s[0]}">${esc(s[1])}</button>`).join('')}</div>
    ${genres.length ? `<div class="chips sm">${genres.map((g) => `<button class="chip${S.f.genre === g ? ' on' : ''}" data-act="genre" data-v="${g}">${esc(t(GENRES[g]))}</button>`).join('')}</div>` : ''}
    <div id="grid" class="grid">${gridHtml()}</div>`;
}

function busyHtml(id, b) {
  let label = t('Preparing…');
  let pct = 0;
  if (b.state === 'download') {
    pct = b.total ? Math.min(100, (b.done / b.total) * 100) : 0;
    label = t('Downloading {a} / {b}', { a: fmtSize(b.done), b: fmtSize(b.total) });
  } else if (b.state === 'installing') {
    pct = 100;
    label = t('Installing… confirm in the Android window');
  }
  const ind = b.state === 'download' ? '' : ' ind';
  return `<div class="busy" data-prog="${esc(id)}"><div class="bar${ind}"><i style="width:${pct}%"></i></div>
    <div class="bl"><span class="pt">${esc(label)}</span><button class="lnk" data-act="cancel" data-id="${esc(id)}">${t('Cancel')}</button></div></div>`;
}

function actionsHtml(a, ctx) {
  const id = esc(a.id);
  if (ctx.busy) return busyHtml(a.id, ctx.busy);
  const out = [];
  if (ctx.installed) {
    out.push(`<button class="btn pri" data-act="launch" data-id="${id}">${svg('play')} ${t('Play')}</button>`);
    if (ctx.upd) out.push(`<button class="btn" data-act="install" data-id="${id}">${svg('download')} ${t('Update')} · ${esc(ctx.best.rel.tag_name)}</button>`);
    out.push(`<button class="btn ghost" data-act="uninstall" data-id="${id}">${svg('trash')} ${t('Uninstall')}</button>`);
    const v = (S.live[a.id] && S.live[a.id].versionName) || S.inst[a.id].tag;
    out.push(`<div class="note w100">${t('Installed version')} : ${esc(v)}</div>`);
  } else if (ctx.best) {
    out.push(`<button class="btn pri" data-act="install" data-id="${id}">${svg('download')} ${t('Install')} · ${esc(fmtSize(ctx.best.asset.size))}</button>`);
  } else if (ctx.p.loading) {
    out.push(`<div class="note"><span class="spin"></span> ${t('Looking for an Android build…')}</div>`);
  } else if (ctx.p.err) {
    out.push(`<div class="note bad">${esc(ctx.p.err)}</div><button class="btn" data-act="retry" data-id="${id}">${t('Retry')}</button>`);
  } else {
    out.push(`<div class="note">${t('No Android build in the releases')}</div>`);
  }
  return out.join('');
}

function viewGame() {
  const id = S.route.id;
  const a = byId(id);
  if (!a) return `<button class="lnk back" data-act="back">${svg('back')} ${t('Back')}</button><div class="empty">${t('Not found')}</div>`;
  const p = S.page && S.page.id === id ? S.page : { loading: true };
  const installed = isInstalled(id);
  const best = p.list ? latestApk(p.list, a) : null;
  const upd = installed && !!best && best.sig !== S.inst[id].sig;
  const bg = a.hero || a.cover;
  const owner = a.author || (a.repo || '').split('/')[0];
  const chips = [];
  if (a.genre && GENRES[a.genre]) chips.push(t(GENRES[a.genre]));
  if (a.origin) chips.push(originName(a.origin));
  (a.systems || []).forEach((s) => chips.push(OS_NAME[s] || s));
  if (best && (a.systems || []).indexOf('android') < 0) chips.push('Android');

  let versions = '';
  const rows = p.list ? apkReleases(p.list, a, 6) : [];
  if (rows.length) {
    versions = `<section class="card"><h3>${t('Android versions')}</h3><div class="list">${rows.map((r) => {
      const cur = installed && S.inst[id].sig === r.sig;
      const checked = r.asset.digest ? ` · ${t('checked by GitHub')}` : '';
      return `<div class="vrow"><div class="grow"><b>${esc(r.rel.tag_name)}</b>${r.rel.prerelease ? ` <span class="chip sm2">${t('pre-release')}</span>` : ''}
        <div class="muted s">${esc(r.asset.name)} · ${esc(fmtSize(r.asset.size))} · ${esc(fmtDate(r.rel.published_at))}${checked}</div></div>
        ${cur ? `<span class="muted">${t('Installed ✓')}</span>` : `<button class="btn sm" data-act="install" data-id="${esc(id)}" data-sig="${esc(r.sig)}" ${S.busy[id] ? 'disabled' : ''}>${t('Install')}</button>`}</div>`;
    }).join('')}</div></section>`;
  }
  const notes = best && best.rel.body
    ? `<details class="card"><summary>${t('Release notes')} · ${esc(best.rel.tag_name)}</summary><pre class="notes">${esc(String(best.rel.body).slice(0, 4000))}</pre></details>` : '';
  const repoUrl = a.repo ? 'https://github.com/' + a.repo : '';
  const links = repoUrl
    ? `<div class="links"><button class="lnk" data-act="ext" data-url="${esc(repoUrl)}">${svg('ext')} ${t('Source on GitHub')}</button>
       <button class="lnk" data-act="ext" data-url="${esc(repoUrl)}/releases">${svg('ext')} ${t('Releases')}</button>
       <button class="lnk" data-act="ext" data-url="${esc(repoUrl)}/issues">${svg('ext')} ${t('Issues')}</button></div>` : '';

  return `
    <button class="lnk back" data-act="back">${svg('back')} ${t('Back')}</button>
    <section class="ghero">${bg ? `<div class="gbg" style="background-image:url('${esc(thumb(bg, 960))}')"></div>` : ''}
      <div class="gin"><div class="gposter">${a.cover ? img(a.cover, 400, a.name) : ''}</div>
        <div class="gtxt"><h1>${esc(a.name)}</h1>
          ${owner ? `<div class="muted">${t('By {who}', { who: '<b>' + esc(owner) + '</b>' })}</div>` : ''}
          ${a.blurb ? `<p class="blurb">${esc(a.blurb)}</p>` : ''}
          <div class="chips ro">${chips.map((c) => `<span class="chip">${esc(c)}</span>`).join('')}</div>
          <div class="act">${actionsHtml(a, { p, installed, best, upd, busy: S.busy[id] })}</div>
        </div></div></section>
    ${permBanner()}${versions}${notes}
    <section class="card"><h3>${t('Before you play')}</h3><p class="muted">${t('You need your own copy of the game. RecompLauncher never includes or downloads game files: the recomp tells you where to put yours.')}</p></section>
    ${links}`;
}

function libRow(id) {
  const r = S.inst[id];
  const live = S.live[id];
  const busy = S.busy[id];
  const u = S.upd[id];
  const status = u ? `<span class="bd upd inl">${t('Update available')} · ${esc(u.rel.tag_name)}</span>` : `<span class="muted s">${t('Up to date')}</span>`;
  const btns = busy ? '' : `<button class="btn pri sm" data-act="launch" data-id="${esc(id)}">${svg('play')} ${t('Play')}</button>
    ${u ? `<button class="btn sm" data-act="install" data-id="${esc(id)}">${t('Update')}</button>` : ''}
    <button class="ibtn" data-act="uninstall" data-id="${esc(id)}" aria-label="${esc(t('Uninstall'))}">${svg('trash')}</button>`;
  return `<div class="lrow"><button class="lcov" data-act="open" data-id="${esc(id)}">${r.cover ? img(r.cover, 160, r.name) : ''}</button>
    <div class="grow"><button class="lname" data-act="open" data-id="${esc(id)}">${esc(r.name)}</button>
      <div class="muted s">${esc((live && live.versionName) || r.tag)} · ${status}</div>${busy ? busyHtml(id, busy) : ''}</div>
    <div class="lbtns">${btns}</div></div>`;
}

function viewLib() {
  const ids = Object.keys(S.inst).filter((id) => S.live[id] || S.busy[id]);
  return `<header class="top"><h1>${t('Library')}</h1><button class="ibtn" data-act="checkupd" aria-label="${esc(t('Check for updates'))}">${svg('refresh')}</button></header>
    ${permBanner()}
    ${ids.length ? `<div class="list">${ids.map(libRow).join('')}</div>`
    : `<div class="empty"><p>${t('Nothing installed yet')}</p><p class="muted">${t('Install a recomp from Discover, or add one from GitHub.')}</p></div>`}`;
}

function viewAdd() {
  return `<header class="top"><h1>${t('Add')}</h1></header>
    <section class="card"><h3>${t('Add a recomp from GitHub')}</h3>
      <p class="muted">${t('Paste a GitHub link (or owner/repo). Its releases must contain an Android .apk.')}</p>
      <div class="inrow"><input id="repo" type="url" inputmode="url" value="${esc(S.addVal)}" placeholder="github.com/owner/repo" autocomplete="off" autocapitalize="off" spellcheck="false">
        <button class="btn pri" data-act="addrepo" ${S.addBusy ? 'disabled' : ''}>${S.addBusy ? t('Looking…') : t('Look up')}</button></div>
      <div class="note${S.addErr ? ' bad' : ''}">${esc(S.addMsg)}</div></section>
    ${S.mine.length ? `<h3 class="sub">${t('Your recomps')}</h3><div class="list">${S.mine.map((m) => `<div class="lrow"><div class="grow"><button class="lname" data-act="open" data-id="${esc(m.id)}">${esc(m.name)}</button><div class="muted s">${esc(m.repo)}</div></div>
      <button class="btn ghost sm" data-act="rmmine" data-id="${esc(m.id)}">${t('Remove')}</button></div>`).join('')}</div>` : ''}`;
}

function toggle(key, title, hint) {
  return `<label class="setrow"><div class="grow"><b>${t(title)}</b><div class="muted s">${t(hint)}</div></div>
    <span class="sw"><input type="checkbox" data-set="${key}" ${S.set[key] ? 'checked' : ''}><i></i></span></label>`;
}

function viewSet() {
  const n = S.native;
  return `<header class="top"><h1>${t('Settings')}</h1></header>
    <section class="card">
      ${toggle('pre', 'Include pre-releases', 'Betas and nightly builds')}
      ${toggle('relay', 'Release info through recomplauncher.com', "Faster, and avoids GitHub's request limit. Off = straight from GitHub.")}
      <div class="setrow col"><b>${t('GitHub token (optional)')}</b><div class="muted s">${t('Only used when asking GitHub directly, to raise its request limit.')}</div>
        <input type="password" data-set="token" value="${esc(S.set.token)}" placeholder="ghp_…" autocomplete="off" autocapitalize="off" spellcheck="false"></div>
      <div class="setrow"><b class="grow">${t('Language')}</b>
        <select data-set="lang"><option value="auto"${S.set.lang === 'auto' ? ' selected' : ''}>${t('Automatic')}</option><option value="fr"${S.set.lang === 'fr' ? ' selected' : ''}>Français</option><option value="en"${S.set.lang === 'en' ? ' selected' : ''}>English</option></select></div>
      <div class="setrow"><b class="grow">${t('Clear cache')}</b><button class="btn sm" data-act="clearcache">${t('Clear cache')}</button></div>
    </section>
    <section class="card"><h3>${t('About')}</h3>
      <p class="muted">${t('Unofficial Android version of RecompLauncher by Ripalda (GPL-3.0).')}</p>
      <p class="muted s">v${esc(n.version)} · ${t('Device')} : ${esc(n.device || '—')} · Android ${esc(n.sdk || '—')}<br>${t('Supported CPUs')} : ${esc((n.abis || []).join(', '))}</p>
      <div class="links"><button class="lnk" data-act="ext" data-url="https://github.com/elripalda/RecompLauncher">${svg('ext')} RecompLauncher (PC)</button>
      <button class="lnk" data-act="ext" data-url="https://recomplauncher.com">${svg('ext')} recomplauncher.com</button></div>
    </section>`;
}

// ---------- affichage ----------
function renderNav() {
  const items = [['discover', 'Discover', 'compass'], ['lib', 'Library', 'grid'], ['add', 'Add', 'plus'], ['set', 'Settings', 'sliders']];
  const n = Object.keys(S.upd).length;
  $('#nav').innerHTML = '<img class="brand" src="img/mark.svg" alt="RecompLauncher">' + items.map((it) =>
    `<button class="nv${tabOf() === it[0] ? ' on' : ''}" data-act="tab" data-tab="${it[0]}">${svg(it[2])}<span>${esc(t(it[1]))}</span>${it[0] === 'lib' && n ? `<b class="n">${n}</b>` : ''}</button>`).join('');
}

function render(reset) {
  const main = $('#main');
  const y = main.scrollTop;
  const views = { discover: viewDiscover, lib: viewLib, add: viewAdd, set: viewSet, game: viewGame };
  main.innerHTML = (views[S.route.n] || viewDiscover)();
  main.scrollTop = reset ? 0 : y;
  renderNav();
}

function go(n, arg, from) {
  S.stack.push(Object.assign({}, S.route, { y: $('#main').scrollTop }));
  S.route = { n, id: arg, from };
  render(true);
}

function tab(k) {
  S.stack = [];
  S.route = { n: k };
  if (k === 'lib') { refreshPkgs(); checkUpdates(false); }
  render(true);
}

// Bouton retour d'Android : true si la page l'a géré
function back() {
  if (S.stack.length) {
    const r = S.stack.pop();
    S.route = { n: r.n, id: r.id, from: r.from };
    render();
    $('#main').scrollTop = r.y || 0;
    return true;
  }
  if (S.route.n !== 'discover') { S.route = { n: 'discover' }; render(true); return true; }
  return false;
}
window.__back = back;

async function loadPage(id, force) {
  const a = byId(id);
  if (!a || !a.repo) { S.page = { id, list: [] }; render(); return; }
  S.page = { id, loading: true };
  render();
  try {
    const list = await releases(a.repo, !!force);
    S.page = { id, list };
    if (S.inst[id]) { const best = latestApk(list, a); if (best && best.sig !== S.inst[id].sig) S.upd[id] = best; else delete S.upd[id]; }
  } catch (e) {
    S.page = { id, err: e.message };
  }
  if (S.route.n === 'game' && S.route.id === id) render();
}

function openGame(id) {
  go('game', id, tabOf());
  loadPage(id, false);
}

let toastTimer = 0;
function toast(m) {
  const el = $('#toast');
  el.textContent = m;
  el.classList.add('on');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('on'), 4200);
}

// ---------- ajouter un dépôt GitHub ----------
async function addRepo() {
  const input = $('#repo');
  S.addVal = input ? input.value : S.addVal;
  S.addErr = false;
  const repo = parseRepo(S.addVal);
  if (!repo) { S.addMsg = t('Not a GitHub repo'); S.addErr = true; render(); return; }
  S.addBusy = true;
  S.addMsg = '';
  render();
  try {
    const list = await releases(repo, true);
    if (!latestApk(list, null)) {
      S.addErr = true;
      S.addMsg = latestApk(list, null, true) ? t('Only pre-releases have an APK: turn them on in Settings.') : t('No Android .apk in the releases of {repo}', { repo });
      S.addBusy = false;
      render();
      return;
    }
    const known = allApps().find((a) => a.repo && a.repo.toLowerCase() === repo.toLowerCase());
    let id;
    if (known) {
      id = known.id;
    } else {
      id = 'my:' + repo.toLowerCase();
      const parts = repo.split('/');
      S.mine = S.mine.filter((m) => m.id !== id);
      S.mine.push({ id, name: parts[1].replace(/[-_]+/g, ' '), repo, author: parts[0], cover: 'https://github.com/' + parts[0] + '.png?size=200', mine: true });
      store.set('mine', S.mine);
    }
    S.addBusy = false;
    S.addVal = '';
    S.addMsg = '';
    toast(t('Added {name}', { name: byId(id).name }));
    openGame(id);
  } catch (e) {
    S.addBusy = false;
    S.addErr = true;
    S.addMsg = e.message;
    render();
  }
}

// ---------- clics et saisies ----------
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const id = el.dataset.id;
  switch (el.dataset.act) {
    case 'tab': tab(el.dataset.tab); break;
    case 'open': openGame(id); break;
    case 'back': back(); break;
    case 'reload': loadCatalog(true); break;
    case 'show': S.f.show = el.dataset.v; render(); break;
    case 'genre': S.f.genre = S.f.genre === el.dataset.v ? '' : el.dataset.v; render(); break;
    case 'scan': scan(); break;
    case 'scanstop': S.scan.stop = true; break;
    case 'install': doInstall(id, el.dataset.sig || ''); break;
    case 'cancel': nat.cancel(id); delete S.busy[id]; delete S.pending[id]; render(); break;
    case 'launch': if (!nat.launch((S.inst[id] || {}).pkg)) toast(t("Can't launch this game")); break;
    case 'uninstall': if (S.inst[id]) nat.uninstall(S.inst[id].pkg); break;
    case 'perm': nat.perm(); break;
    case 'retry': loadPage(id, true); break;
    case 'checkupd': refreshPkgs(); checkUpdates(true); break;
    case 'addrepo': addRepo(); break;
    case 'rmmine': S.mine = S.mine.filter((m) => m.id !== id); store.set('mine', S.mine); render(); break;
    case 'ext': nat.open(el.dataset.url); break;
    case 'clearcache': nat.clear(); S.rels = {}; toast(t('Cache cleared')); break;
    default: break;
  }
});

document.addEventListener('input', (e) => {
  if (e.target.id === 'q') {
    S.f.q = e.target.value;
    $('#grid').innerHTML = gridHtml();
  }
});

document.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && e.target.id === 'repo') addRepo();
});

document.addEventListener('change', (e) => {
  const key = e.target.dataset && e.target.dataset.set;
  if (!key) return;
  S.set[key] = e.target.type === 'checkbox' ? e.target.checked : e.target.value;
  store.set('set', S.set);
  if (key === 'pre' || key === 'relay') { S.rels = {}; S.upd = {}; checkUpdates(false); }
  if (key === 'lang') render();
});

// ---------- démarrage ----------
window.__rl = { pickApk, abiOf, parseRepo, sigOf, latestApk, globMatch, S };

(function boot() {
  S.native = nat.info();
  refreshPkgs();
  renderNav();
  loadCatalog(false).then(() => checkUpdates(false));
})();
})();
