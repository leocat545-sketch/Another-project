package dev.leocat.recomplauncher;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Une seule fenêtre : un WebView qui affiche l'interface (assets/web). Tout ce qui touche à Android
 * (installer, lancer, désinstaller) passe par Bridge ; le réseau passe par Net.
 */
public class MainActivity extends Activity {
    static final String HOST = "appassets.androidplatform.net";
    static final String HOME = "https://" + HOST + "/index.html";

    /** L'activité ouverte, pour que le téléchargement et l'installeur puissent écrire à la page. */
    static volatile MainActivity current;

    private WebView web;
    private Net net;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        current = this;

        Window w = getWindow();
        w.setStatusBarColor(0xFF08101C);
        w.setNavigationBarColor(0xFF08101C);

        net = new Net(getCacheDir());
        Installer installer = new Installer(this);

        web = new WebView(this);
        web.setBackgroundColor(0xFF0B1220);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(this, installer, net), "Android");

        setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.loadUrl(HOME);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // La page revérifie ce qui est installé (au retour de l'écran d'installation, par exemple).
        emit("resume", new JSONObject());
    }

    @Override
    protected void onDestroy() {
        if (current == this) current = null;
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // La page gère d'abord le retour (fiche d'un jeu -> liste) ; sinon on quitte.
        web.evaluateJavascript("(window.__back&&window.__back())===true", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    /** Envoie un événement à la page : window.__native.emit(nom, données). Peut venir de n'importe quel thread. */
    static void emit(String event, JSONObject data) {
        final MainActivity a = current;
        if (a == null || a.web == null) return;
        final String js = "window.__native&&window.__native.emit(" + JSONObject.quote(event) + "," + data + ")";
        a.web.post(() -> a.web.evaluateJavascript(js, null));
    }

    private final class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (!HOST.equals(u.getHost())) return null; // images et autres : le réseau normal
            String path = u.getPath();
            if (path == null || path.equals("/")) path = "/index.html";
            if (path.equals("/__net")) return net.serve(req);
            return asset(path);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
            Uri u = req.getUrl();
            if (HOST.equals(u.getHost())) return false;
            if ("https".equals(u.getScheme())) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (RuntimeException ignored) {
                    // pas de navigateur : rien à faire
                }
            }
            return true;
        }
    }

    private WebResourceResponse asset(String path) {
        try {
            InputStream in = getAssets().open("web" + path);
            Map<String, String> h = new HashMap<>();
            h.put("Cache-Control", "no-cache");
            return new WebResourceResponse(mime(path), "utf-8", 200, "OK", h, in);
        } catch (IOException e) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                    new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
        }
    }

    private static String mime(String path) {
        String p = path.toLowerCase();
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".js")) return "text/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".json")) return "application/json";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }
}
